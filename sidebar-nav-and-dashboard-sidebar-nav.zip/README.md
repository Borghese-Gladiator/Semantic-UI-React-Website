# recipe-sharing-site
Website to share recipes similar to allrecipes && other recipe sharing sites, however, it is marketed towards a different audience.

### Users
Asian American families who want to share their completed dishes (& recipes) with friends in their ***native language***

### Author
Borghese-Gladiator

