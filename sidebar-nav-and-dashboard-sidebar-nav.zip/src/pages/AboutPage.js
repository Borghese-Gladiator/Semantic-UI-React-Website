import React from 'react'

export default function AboutPage(props) {
  return (
    <h2>ABOUT</h2>
  )
}