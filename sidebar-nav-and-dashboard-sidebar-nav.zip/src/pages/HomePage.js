import React from 'react'
import Landing from '../components/Landing'

export default function AboutPage(props) {
  return (
    <div>
      <h2>HOME</h2>
      <Landing />
    </div>
  )
}