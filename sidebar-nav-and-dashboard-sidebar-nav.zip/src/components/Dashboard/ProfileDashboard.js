import React from 'react'

export default function ProfileDashboard() {
  return (
    <h2>PROFILE</h2>
  )
}