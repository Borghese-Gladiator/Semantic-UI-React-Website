import React from 'react'

export default function HistoryDashboard() {
  return (
    <h2>History</h2>
  )
}