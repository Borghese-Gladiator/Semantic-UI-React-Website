import React from 'react'

export default function HomeDashboard() {
  return (
    <h2>HOME</h2>
  )
}