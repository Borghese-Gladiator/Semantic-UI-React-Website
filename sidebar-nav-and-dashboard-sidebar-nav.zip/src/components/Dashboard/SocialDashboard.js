import React from 'react'

export default function SocialDashboard() {
  return (
    <h2>SOCIAL</h2>
  )
}